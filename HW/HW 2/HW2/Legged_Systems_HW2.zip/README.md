# R16868 Assignment 2 — Overleaf Project

Upload the entire contents of this folder to Overleaf, or upload the ZIP directly.

## Main file
- `main.tex`

## MATLAB helper files
Located in `matlab/`:
- `m07_params_A2.m`
- `make_A2_goals.m`
- `goal_scheduler_block.m`
- `foot_placement_block.m`
- `plot_A2_results.m`

## Figures
After running MATLAB/Simulink, export your figures as:
- `figures/left_turn.png`
- `figures/right_turn.png` (optional)
- `figures/figure8.png`
- `figures/double_support_speed.png` (optional)

The LaTeX source compiles even if the required figures are not yet present; placeholder boxes will appear instead.

## Values to replace before submission
Search `main.tex` for `INSERT` and replace:
- maximum leg length for left-quarter turn
- final maximum leg length for figure-eight
- figure-eight x span
- figure-eight y span
- optional double-support values/results if completed

Also replace `[was/was not]` and `[remained/did not remain]` with the correct wording after simulation.

## MP4
The report references `figure8_lipm.mp4`, which should be submitted separately if required by the course platform.

## Completed simulation results

Left quarter-turn simulation:
- Nominal commanded radius: 3.1831 m
- Fitted CoM turning radius: 2.8718 m
- Maximum stance-leg length: 0.8561 m (< 0.9000 m limit)

These values have been inserted into `main.tex`. The remaining numerical placeholders are for the final figure-eight simulation (and the optional double-support section, if completed).
